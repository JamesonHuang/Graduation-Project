package com.entity;

public class User {
	private int id;// integer primary key auto_increment,
	private String account;// varchar(20) not null,
	private String password;// varchar(20) not null,
	private String photo;// varchar(100),
	private String name;// varchar(50),
	private String weixinNo;// varchar(50),
	private String address;// varchar(100),
	private String sex;// char(1),
	private String area;// varchar(50),
	private String sign;// varchar(100)
	public User() {
		// TODO Auto-generated constructor stub
	}
	public User(int id, String account, String password, String photo, String name,
			String weixinNo, String address, String sex, String area, String sign) {
		super();
		this.id = id;
		this.account = account;
		this.password = password;
		this.photo = photo;
		this.name = name;
		this.weixinNo = weixinNo;
		this.address = address;
		this.sex = sex;
		this.area = area;
		this.sign = sign;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getWeixinNo() {
		return weixinNo;
	}
	public void setWeixinNo(String weixinNo) {
		this.weixinNo = weixinNo;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getSign() {
		return sign;
	}
	public void setSign(String sign) {
		this.sign = sign;
	}
	@Override
	public String toString() {
		return "User [id=" + id + ", account=" + account + ", password=" + password + ", photo="
				+ photo + ", name=" + name + ", weixinNo=" + weixinNo + ", address=" + address
				+ ", sex=" + sex + ", area=" + area + ", sign=" + sign + "]";
	}
	
}
