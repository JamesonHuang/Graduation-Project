package com.dao;

import com.entity.User;

public interface IUserDao {

	//�û���¼
	User login(String account,String password);
}
