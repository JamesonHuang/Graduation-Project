create table weixin_user
(
	id integer primary key auto_increment,
	account varchar(20) not null,
	password varchar(20) not null,
	photo varchar(100),
	name varchar(50),
	weixin_no varchar(50),
	address varchar(100),
	sex char(1),
	area varchar(50),
	sign varchar(100)
)

insert into weixin_user(account,password,photo,name,weixin_no,address,sex,area,sign) values('stone','1234','/images/stone_photo.png','stone','stone','�����а�����','1','������','android�Ǹ��ö���');