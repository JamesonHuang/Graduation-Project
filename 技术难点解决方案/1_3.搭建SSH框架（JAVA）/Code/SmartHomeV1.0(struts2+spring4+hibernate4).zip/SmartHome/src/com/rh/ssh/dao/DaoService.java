﻿package com.rh.ssh.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

public interface DaoService<T> {

	void add(T t) throws Exception;

	void delete(T t) throws Exception;

	void update(T t) throws Exception;

	void merge(T t) throws Exception;

	void addAll(List<T> list) throws Exception;

	void updateAll(List<T> list) throws Exception;

	void mergeAll(List<T> list) throws Exception;

	void deleteAll(List<T> list) throws Exception;

	@SuppressWarnings("rawtypes")
	Object get(Class entityClass, Serializable id) throws Exception;

	int executeHQL(String hql) throws Exception;

	int executeHQL(String hql, String param, Object value) throws Exception;

	int executeHQL(String hql, Map<String, Object> param) throws Exception;

	List<T> find(String hql) throws Exception;

	List<T> find(String hql, String param, Object value) throws Exception;

	List<T> find(String hql, Map<String, Object> param) throws Exception;

	Object findFirst(String hql) throws Exception;

	Object findFirst(String hql, String param, Object value) throws Exception;

	Object findFirst(String hql, Map<String, Object> param) throws Exception;

	List<T> findLimit(String hql, int first, int max) throws Exception;

	List<T> findLimit(String hql, String param, Object value, int first, int max) throws Exception;

	List<T> findLimit(String hql, Map<String, Object> param, int first, int max) throws Exception;

	Object findUnique(String hql) throws Exception;

	Object findUnique(String hql, String param, Object value) throws Exception;

	Object findUnique(String hql, Map<String, Object> param) throws Exception;

	int executeSQL(String sql) throws Exception;

	int executeSQL(String sql, String param, Object value) throws Exception;

	int executeSQL(String sql, Map<String, Object> param) throws Exception;

	List<T> executeSQLQuery(String sql) throws Exception;

	List<T> executeSQLQuery(String sql, String param, Object value) throws Exception;

	List<T> executeSQLQuery(String sql, Map<String, Object> param) throws Exception;
}