package com.rh.hibernate.dao;

import org.hibernate.HibernateException;  

import com.rh.hibernate.beans.User;

public interface BaseDao {  
  
    public void saveObject(Object obj) throws HibernateException;  
    public void delObject(Object obj) throws HibernateException;
    public void updateObject(Object obj) throws HibernateException;
    public void validObject(Object obj) throws HibernateException;
    public void findByUserName(User user) throws HibernateException;
}

/*import org.hibernate.HibernateException;  
import org.hibernate.Session;  
  
public interface BaseDao {  
  
    public void saveObject(Object obj) throws HibernateException;  
  
    public Session getSession();  
  
    public void setSession(Session session);  
}*/

 