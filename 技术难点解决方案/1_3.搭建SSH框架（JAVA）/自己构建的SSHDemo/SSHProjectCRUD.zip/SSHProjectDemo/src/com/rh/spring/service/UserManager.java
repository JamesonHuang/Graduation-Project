package com.rh.spring.service;

import com.rh.struts.forms.UserForm;
  
public interface UserManager {  
  
    public void regUser(UserForm user);
    
    public void updateUser(UserForm user);    
    
    public void deleteUser(UserForm user);     
    
    public void loginUser(UserForm user);
    
  
}  