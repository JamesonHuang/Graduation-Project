/**  
* @Title: 		UserManagerImpl.java
* @Package: 		com.rh.spring.serviceImpl
* @Description: 	TODO(用一句话描述该文件做什么)
* @author: 		rh_Jameson  
* @date:			2014年10月15日 上午11:39:29
*
*/ 
package com.rh.spring.serviceImpl;

import org.hibernate.HibernateException;  

//import com.rh.hibernate.daoImpl.UserDao;  
import com.rh.hibernate.beans.User;  
import com.rh.hibernate.dao.BaseDao;  
import com.rh.spring.service.UserManager;
import com.rh.struts.forms.UserForm;  

import org.springframework.beans.BeanUtils; 

  
public class UserManagerImpl implements UserManager {  
  
    private BaseDao dao;  
  
    public void setDao(BaseDao dao) {  
        this.dao = dao;  
    }  
  
    @Override  
    public void regUser(UserForm userForm) throws HibernateException {  
        User user = new User();  
        BeanUtils.copyProperties(userForm, user);  
        dao.saveObject(user);  
    }
    
    @Override  
    public void updateUser(UserForm userForm) throws HibernateException {  
        User user = new User();  
        BeanUtils.copyProperties(userForm, user);
        dao.findByUserName(user);
        dao.updateObject(user);
    }
    
    @Override  
    public void deleteUser(UserForm userForm) throws HibernateException {  
        User user = new User();  
        BeanUtils.copyProperties(userForm, user);  
        dao.delObject(user);
    }
    
    @Override  
    public void loginUser(UserForm userForm) throws HibernateException {  
        User user = new User();  
        BeanUtils.copyProperties(userForm, user);  
        dao.validObject(user);
    }
    
    
    
}
 
