package com.rh.hibernate.daoImpl;

import org.hibernate.HibernateException;  
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;




import com.rh.hibernate.beans.User;
//3.support.HibernateDaoSupport;  
import com.rh.hibernate.dao.BaseDao;  

public class UserDao extends HibernateDaoSupport implements BaseDao {  
  
    @Override  
    public void saveObject(Object obj) throws HibernateException {  
        getHibernateTemplate().save(obj);
        
    }
    
    public void delObject(Object obj) throws HibernateException {
	    getHibernateTemplate().delete(obj);
    }
    public void updateObject(Object obj) throws HibernateException{	  
            getHibernateTemplate().update(obj);              
    }
    public void validObject(Object obj) throws HibernateException{
	    getHibernateTemplate().find("from bean.user u where u.name=? and u.password=?", "admin","admin");
	    /*String hql= "from bean.User u where u.name=? and u.password=?";
	    getHibernateTemplate().find(hql, new String[]{"test", "123"});*/
    }
    public void findByUserName(User user) throws HibernateException{	    
	    getHibernateTemplate().find("from bean.user u where u.name=?",user.getUsername());
	    /*String hql= "from bean.User u where u.name=? and u.password=?";
	    getHibernateTemplate().find(hql, new String[]{"test", "123"});*/
    }


  
}

