package com.rh.hibernate.daoImpl;

import org.hibernate.HibernateException;  
import org.springframework.orm.hibernate4.support.HibernateDaoSupport;
//3.support.HibernateDaoSupport;  
import com.rh.hibernate.dao.BaseDao;  

public class UserDao extends HibernateDaoSupport implements BaseDao {  
  
    @Override  
    public void saveObject(Object obj) throws HibernateException {  
        getHibernateTemplate().save(obj);  
    }  
  
}

