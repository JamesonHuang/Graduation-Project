package com.alira.service;

import com.example.service.R;

import android.app.Activity;  
import android.content.Intent;  
import android.os.Bundle;  
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
  
public class RATestActivity extends Activity implements OnClickListener{  
    /** Called when the activity is first created. */  
	public Intent intents;
	String TAG="ServiceDemoActivity";
    @Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
        setContentView(R.layout.activity_main);  
        
       /*主界面阻塞，最终会出现Application not responding */
        //startService(new Intent(this,MyService.class)); 
        
        /*连续两次启动IntentService，会发现应用程序不会阻塞，而且最重的是第二次的请求会再第一个请求结束之后运行(这个证实了IntentService采用单独的线程每次只从队列中拿出一个请求进行处理) */ 
        intents = new Intent(this,RAIntentService.class);
        Button bton = (Button) findViewById(R.id.bton);  
        Button btoff = (Button) findViewById(R.id.btoff);  
        bton.setOnClickListener(this);  
        btoff.setOnClickListener(this); 
        //startService(intents);  
    }  
    
    @Override
    protected void onStop() {
    	// TODO Auto-generated method stub
    	//stopService(intents);
    	super.onStop();
    }

	@Override
	public void onClick(View v) {
		// TODO Auto-generated method stub
		int id = v.getId();  
        switch (id) {  
            case R.id.bton :
            	Log.i(TAG, "on");
            	startService(intents);
            	
                break;  
            case R.id.btoff :  
            	Log.i(TAG, "off");
            	stopService(intents);
            default :  
                break;  
        }  
	}
}  