package com.alira.service;

import de.tavendo.autobahn.WebSocketConnection;
import de.tavendo.autobahn.WebSocketException;
import de.tavendo.autobahn.WebSocketHandler;
import android.app.IntentService;  
import android.content.Intent;  
import android.os.IBinder;
import android.util.Log;
	
    public class RAIntentService extends IntentService {  
    	String TAG = "MyIntentService";
    	Thread thr;
    	int running = 0;
    	WebSocketConnection wsc;  
        public RAIntentService() {  
            super("MyIntentService");  
        }   
        
        @Override
        public void onCreate() {
        	// TODO Auto-generated method stub
        	Log.i(TAG,"onCreate"); 
        	wsc = new WebSocketConnection();  
        	super.onCreate();
        }
        
        @Override
        public IBinder onBind(Intent intent) {
        	// TODO Auto-generated method stub
        	return super.onBind(intent);
        }
        
        @Override
        public void onDestroy() {
        	// TODO Auto-generated method stub
        	Log.i(TAG,"onDestroy"); 
        	running = 0;
        	wsc.disconnect();
        	super.onDestroy();
        }
        
        @Override  
        protected void onHandleIntent(Intent intent) {  
            // 经测试，IntentService里面是可以进行耗时的操作的  
            //IntentService使用队列的方式将请求的Intent加入队列，然后开启一个worker thread(线程)来处理队列中的Intent  
            //对于异步的startService请求，IntentService会处理完成一个之后再处理第二个  
        	Log.i(TAG,"onHandleIntent"); 
        	if(running!=1)
        	{
        		running = 1;
        		connect();
	        	while (running==1)
	        	{
	        		try {  
	                    Thread.sleep(5000);  
	                } catch (InterruptedException e) {  
	                    e.printStackTrace();  
	                }  
	        		Log.i(TAG,"thread is runing");  
	        		wsc.sendTextMessage("sending..."); 
	        	}
        	}
        } 
        
        
        private void connect() {  
            try {  
                wsc.connect("ws://10.68.33.219:8080",  
                        new WebSocketHandler() {  
                      		
                            @Override  
                            public void onBinaryMessage(byte[] payload) {  
                                System.out.println("onBinaryMessage size="  
                                        + payload.length);  
                            }  
      
                            @Override  
                            public void onClose(int code, String reason) {  
                                System.out.println("onClose reason=" + reason);  
                            }  
      
                            @Override  
                            public void onOpen() {  
                                System.out.println("onOpen");  
                                Log.i(TAG,"onOpen");
                                wsc.sendTextMessage("Hello!");  
                                // wsc.disconnect();  
                            }  
                            @Override  
                            public void onRawTextMessage(byte[] payload) {  
                                Log.i(TAG," onRawTextMessage payload = "+payload);
                            }  
      
                            @Override  
                            public void onTextMessage(String payload) {  
                                Log.i(TAG,"onTextMessage payload = "+payload);
                            }  
      
                        });  
            } catch (WebSocketException e) {  
                // TODO Auto-generated catch block  
                e.printStackTrace();  
            }  
      
        }  
        
    }  