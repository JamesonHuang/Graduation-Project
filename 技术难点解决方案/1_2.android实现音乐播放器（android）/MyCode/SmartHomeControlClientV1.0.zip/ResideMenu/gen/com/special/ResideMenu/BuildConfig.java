/** Automatically generated file. DO NOT MODIFY */
package com.special.ResideMenu;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}