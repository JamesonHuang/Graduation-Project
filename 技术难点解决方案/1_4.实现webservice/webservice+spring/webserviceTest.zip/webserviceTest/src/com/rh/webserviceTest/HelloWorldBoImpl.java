package com.rh.webserviceTest;

import com.rh.webserviceTest.HelloWorldBo;

public class HelloWorldBoImpl implements HelloWorldBo{

	public String getHelloWorld(){
		return "JAX-WS + Spring!";
	}
	
}