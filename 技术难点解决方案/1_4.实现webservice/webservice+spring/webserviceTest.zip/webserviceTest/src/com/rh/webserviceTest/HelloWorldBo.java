package com.rh.webserviceTest;

public interface HelloWorldBo{

	String getHelloWorld();
	
}