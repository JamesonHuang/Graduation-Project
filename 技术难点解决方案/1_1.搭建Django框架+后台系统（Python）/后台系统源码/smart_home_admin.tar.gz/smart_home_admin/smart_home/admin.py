

#!/usr/bin/env python
# coding: utf-8

from django.contrib import admin
from smart_home.models import BgInfo,BgInfoimg,BgInfotype,TbDevice,TbMessage,TbMessageType,TbProDetail,TbProject,TbTask,TbTaskDetail,TbUser




admin.site.register( BgInfo)
admin.site.register( BgInfoimg)
admin.site.register( BgInfotype )
admin.site.register( TbDevice)
admin.site.register( TbMessage )
admin.site.register( TbMessageType )
admin.site.register( TbProDetail )
admin.site.register( TbProject )
admin.site.register( TbTask )
admin.site.register( TbTaskDetail)
admin.site.register( TbUser)

