# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
#
# Also note: You'll have to insert the output of 'django-admin sqlcustom [app_label]'
# into your database.
from __future__ import unicode_literals

from django.db import models



class BgInfo(models.Model):
    info_id = models.IntegerField(primary_key=True)
    admin_id = models.IntegerField(blank=True, null=True)
    info_type_id = models.IntegerField(blank=True, null=True)
    info_con = models.TextField(blank=True)
    info_title = models.CharField(max_length=70, blank=True)
    info_date = models.DateTimeField(blank=True, null=True)
    info_hits = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'bg_info'


class BgInfoimg(models.Model):
    info_img_id = models.IntegerField(primary_key=True)
    info_id = models.IntegerField(blank=True, null=True)
    info_img_name = models.CharField(max_length=100, blank=True)
    info_img_path = models.CharField(max_length=250, blank=True)

    class Meta:
        managed = False
        db_table = 'bg_infoimg'


class BgInfotype(models.Model):
    info_type_id = models.IntegerField(primary_key=True)
    info_type_name = models.CharField(max_length=50, blank=True)

    class Meta:
        managed = False
        db_table = 'bg_infotype'




class TbDevice(models.Model):
    device_id = models.IntegerField(primary_key=True)
    device_name = models.CharField(max_length=50, blank=True)
    user_id = models.IntegerField(blank=True, null=True)
    device_key = models.IntegerField(blank=True, null=True)
    is_online = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tb_device'


class TbMessage(models.Model):
    message_id = models.IntegerField(primary_key=True)
    message_type_id = models.IntegerField(blank=True, null=True)
    message_con = models.TextField(blank=True)

    class Meta:
        managed = False
        db_table = 'tb_message'


class TbMessageType(models.Model):
    message_type_id = models.IntegerField(primary_key=True)
    message_type_name = models.CharField(max_length=50, blank=True)

    class Meta:
        managed = False
        db_table = 'tb_message_type'


class TbProDetail(models.Model):
    pro_detail_id = models.IntegerField(primary_key=True)
    pro_detail_from_task = models.CharField(max_length=50, blank=True)
    pro_detail_con = models.CharField(max_length=50, blank=True)

    class Meta:
        managed = False
        db_table = 'tb_pro_detail'


class TbProject(models.Model):
    pro_id = models.IntegerField(primary_key=True)
    pro_name = models.CharField(max_length=50, blank=True)
    pro_intro = models.CharField(max_length=50, blank=True)
    user_id = models.IntegerField(blank=True, null=True)

    class Meta:
        managed = False
        db_table = 'tb_project'


class TbTask(models.Model):
    task_id = models.IntegerField(primary_key=True)
    task_name = models.CharField(max_length=50, blank=True)
    task_type = models.CharField(max_length=50, blank=True)
    task_from_pro = models.CharField(max_length=50, blank=True)
    task_from_task = models.CharField(max_length=50, blank=True)
    task_date = models.CharField(max_length=50, blank=True)
    task_tomatoes_count = models.CharField(max_length=50, blank=True)

    class Meta:
        managed = False
        db_table = 'tb_task'


class TbTaskDetail(models.Model):
    task_detail_id = models.IntegerField(primary_key=True)
    task_detail_from_task = models.CharField(max_length=50, blank=True)
    task_detail_con = models.CharField(max_length=50, blank=True)

    class Meta:
        managed = False
        db_table = 'tb_task_detail'


class TbUser(models.Model):
    user_id = models.IntegerField(primary_key=True)
    user_name = models.CharField(max_length=50, blank=True)
    user_pwd = models.CharField(max_length=50, blank=True)
    weibo_key = models.IntegerField(blank=True, null=True)
    qq_key = models.IntegerField(blank=True, null=True)
    user_img = models.CharField(max_length=200, blank=True)

    class Meta:
        managed = False
        db_table = 'tb_user'
