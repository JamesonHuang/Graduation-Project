#!/usr/bin/env python
# coding: utf-8
import xadmin
#from xadmin import views
#from django.contrib import admin
#from django.core import urlresolvers
from smart_home.models import BgInfo,BgInfoimg,BgInfotype,TbDevice,TbMessage,TbMessageType,TbProDetail,TbProject,TbTask,TbTaskDetail,TbUser






class BgInfoAdmin(object):
    list_display=('info_id','admin_id','info_type_id','info_con','info_title','info_date','info_hits')   #列表显示
    #search_fields=('info_title',)             #搜索
    #list_filter = ('info_id',)             #过滤器
    #date_hierarchy = 'birth'            #日期型字段进行层次划分。
    #ordering = ('info_id')         #对出生日期降序排列，对年级升序
    fields = ('info_id','admin_id','info_type_id','info_con','info_title','info_date','info_hits')    #自定义编辑表单，在编辑表单的时候 显示哪些字段，显示的属性


class BgInfoimgAdmin(object):
    list_display=('info_img_id','info_id','info_img_name','info_img_path')   #列表显示
    fields = ('info_img_id','info_id','info_img_name','info_img_path')    #自定义编辑表单，在编辑表单的时候 显示哪些字段，显示的属性

class BgInfotypeAdmin(object):
    list_display=('info_type_id','info_type_name')   #列表显示
    fields = ('info_type_id','info_type_name')    #自定义编辑表单，在编辑表单的时候 显示哪些字段，显示的属性


class TbDeviceAdmin(object):
    list_display=('device_id','device_name','user_id','device_key','is_online')   #列表显示
    fields = ('device_id','device_name','user_id','device_key','is_online')    #自定义编辑表单，在编辑表单的时候 显示哪些字段，显示的属性

class TbMessageAdmin(object):
    list_display=('message_id','message_type_id','message_con')   #列表显示
    fields = ('message_id','message_type_id','message_con')    #自定义编辑表单，在编辑表单的时候 显示哪些字段，显示的属性

class TbMessageTypeAdmin(object):
    list_display=('message_type_id','message_type_name')   #列表显示
    fields = ('message_type_id','message_type_name')    #自定义编辑表单，在编辑表单的时候 显示哪些字段，显示的属性

class TbProDetailAdmin(object):
    list_display=('pro_detail_id','pro_detail_from_task','pro_detail_con')   #列表显示
    fields = ('pro_detail_id','pro_detail_from_task','pro_detail_con')    #自定义编辑表单，在编辑表单的时候 显示哪些字段，显示的属性

class TbProjectAdmin(object):
    list_display=('pro_id','pro_name','pro_intro','user_id')   #列表显示
    fields = ('pro_id','pro_name','pro_intro','user_id')    #自定义编辑表单，在编辑表单的时候 显示哪些字段，显示的属性


class TbTaskAdmin(object):
    list_display=('task_id','task_name','task_type','task_from_pro','task_from_task','task_date','task_tomatoes_count')   #列表显示
    fields = ('task_id','task_name','task_type','task_from_pro','task_from_task','task_date','task_tomatoes_count')    #自定义编辑表单，在编辑表单的时候 显示哪些字段，显示的属性

class TbTaskDetailAdmin(object):
    list_display=('task_detail_id','task_detail_from_task','task_detail_con')   #列表显示
    fields = ('task_detail_id','task_detail_from_task','task_detail_con')    #自定义编辑表单，在编辑表单的时候 显示哪些字段，显示的属性

class TbUserAdmin(object):
    list_display=('user_id','user_name','user_pwd','weibo_key','qq_key','user_img')   #列表显示
    fields = ('user_id','user_name','user_pwd','weibo_key','qq_key','user_img')    #自定义编辑表单，在编辑表单的时候 显示哪些字段，显示的属性


#xadmin.site.register( BgInfo)
   
xadmin.site.register(BgInfo,BgInfoAdmin)
xadmin.site.register( BgInfoimg,BgInfoimgAdmin)
xadmin.site.register( BgInfotype,BgInfotypeAdmin )
xadmin.site.register( TbDevice,TbDeviceAdmin)
xadmin.site.register( TbMessage,TbMessageAdmin )
xadmin.site.register( TbMessageType,TbMessageTypeAdmin )
xadmin.site.register( TbProDetail,TbProDetailAdmin )
xadmin.site.register( TbProject,TbProjectAdmin )
xadmin.site.register( TbTask,TbTaskAdmin )
xadmin.site.register( TbTaskDetail,TbTaskDetailAdmin)
xadmin.site.register( TbUser,TbUserAdmin)


