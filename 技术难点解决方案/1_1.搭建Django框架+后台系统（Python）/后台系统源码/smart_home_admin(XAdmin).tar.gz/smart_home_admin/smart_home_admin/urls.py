from django.conf.urls import include, url
from django.contrib import admin
import xadmin
from xadmin.plugins import xversion
xadmin.autodiscover()
xversion.register_models()
admin.autodiscover()
urlpatterns = [
    # Examples:
    # url(r'^$', 'smart_home_admin.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),
    #url(r'^$',IndexView.as_view(),name='home'),
    
    url(r'^xadmin/',include(xadmin.site.urls),name='xadmin'),
    url(r'^admin/', include(admin.site.urls)),
]
