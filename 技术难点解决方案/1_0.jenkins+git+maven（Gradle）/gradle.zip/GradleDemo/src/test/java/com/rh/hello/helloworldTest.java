package com.rh.hello;

import static org.junit.Assert.*;

import org.junit.Test;

public class helloworldTest {

	@Test
	public void testMain() {
		System.out.println("testGradle");
		fail("Not yet implemented");
	}

}
