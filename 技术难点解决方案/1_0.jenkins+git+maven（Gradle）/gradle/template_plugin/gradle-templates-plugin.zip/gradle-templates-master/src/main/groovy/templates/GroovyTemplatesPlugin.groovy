/*
 * Copyright (c) 2011,2012 Eric Berry <elberry@tellurianring.com>
 * Copyright (c) 2013 Christopher J. Stehno <chris@stehno.com>
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package templates

import org.gradle.api.Plugin
import org.gradle.api.Project
import templates.tasks.groovy.CreateGroovyClassTask
import templates.tasks.groovy.CreateGroovyProjectTask
import templates.tasks.groovy.ExportGroovyTemplatesTask
import templates.tasks.groovy.InitGroovyProjectTask

/**
 * Adds basic tasks for bootstrapping Groovy projects. Adds createGroovyClass, createGroovyProject,
 * exportGroovyTemplates, and initGroovyProject tasks.
 */
class GroovyTemplatesPlugin implements Plugin<Project> {

	void apply(Project project) {
		project.task 'createGroovyClass',   type:CreateGroovyClassTask
        project.task 'createGroovyProject', type:CreateGroovyProjectTask

		project.task 'exportGroovyTemplates', type:ExportGroovyTemplatesTask

		project.task 'initGroovyProject', type:InitGroovyProjectTask
	}
}