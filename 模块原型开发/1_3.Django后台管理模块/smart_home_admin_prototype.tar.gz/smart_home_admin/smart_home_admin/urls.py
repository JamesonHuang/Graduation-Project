from django.conf.urls import include, url
from django.contrib import admin
import xadmin
from xadmin.plugins import xversion
xadmin.autodiscover()
xversion.register_models()
admin.autodiscover()
#from djangorestframework.views import View

urlpatterns = [
    # Examples:
    # url(r'^$', 'smart_home_admin.views.home', name='home'),
    # url(r'^blog/', include('blog.urls')),
   
#    url(r'^$',IndexView.as_view(),name='home'),
    #url(r'^$',include(xadmin.site.urls),name='xadmin'),
    url(r'^',include(xadmin.site.urls),name='xadmin'),
    url(r'^xadmin/',include(xadmin.site.urls),name='xadmin'),

    url(r'^admin/', include(admin.site.urls)),
]
